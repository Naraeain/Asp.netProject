namespace LuckyDraw.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addTables : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.PrizeLists",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        prizeName = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Prizes",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        PrizeType = c.String(nullable: false),
                        WinningNumber = c.Int(nullable: false),
                        UserId = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.RoleViewModels",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.UserLists",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(),
                        Email = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.WinningNumbers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.String(nullable: false),
                        WinningNumber = c.Int(nullable: false),
                        isRandom = c.String(),
                        Number = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.WinningNumber, unique: true);
            
            AddColumn("dbo.AspNetRoles", "Discriminator", c => c.String(nullable: false, maxLength: 128));
        }
        
        public override void Down()
        {
            DropIndex("dbo.WinningNumbers", new[] { "WinningNumber" });
            DropColumn("dbo.AspNetRoles", "Discriminator");
            DropTable("dbo.WinningNumbers");
            DropTable("dbo.UserLists");
            DropTable("dbo.RoleViewModels");
            DropTable("dbo.Prizes");
            DropTable("dbo.PrizeLists");
        }
    }
}
