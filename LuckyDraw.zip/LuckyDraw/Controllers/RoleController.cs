﻿using LuckyDraw.Models;
using Microsoft.AspNet.Identity.Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using static LuckyDraw.ApplicationSignInManager;
using static LuckyDraw.Models.ApplicationDbContext;

namespace LuckyDraw.Controllers
{
    [Authorize(Roles = "Admin")]
    public class RoleController : Controller
    {
        private ApplicationRoleManager _roleManager;
        private ApplicationUserManager _userManager;

        public RoleController()
        {
        }

        public RoleController(ApplicationUserManager userManager, ApplicationRoleManager roleManager)
        {
            UserManager = userManager;
            RoleManager = roleManager;
            //SignInManager = signInManager;
        }
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        public ApplicationRoleManager RoleManager
        {
            get
            {
                return _roleManager ?? HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
            }
            private set
            {
                _roleManager = value;
            }
        }
        // GET: Role

        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Role
        public ActionResult Index()
        {
            List<RoleViewModel> role = new List<RoleViewModel>();
            foreach (var data in RoleManager.Roles)
                role.Add(new RoleViewModel(data));

            return View(role);
        }

        // GET: Role/Details/5
        //public ActionResult Details(string id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    RoleViewModel roleViewMode
        //    if (roleViewModel == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(roleViewModel);
        //}

        // GET: Role/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Role/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,Name")] RoleViewModel roleViewModel)
        {
            if (ModelState.IsValid)
            {
                var role = new ApplicatoinRole() { Name = roleViewModel.Name };
                await RoleManager.CreateAsync(role);

                return RedirectToAction("Index");
            }

            return View(roleViewModel);
        }

        // GET: Role/Edit/5
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var roleViewModel = await RoleManager.FindByIdAsync(id);

            if (roleViewModel == null)
            {
                return HttpNotFound();
            }
            return View(new RoleViewModel(roleViewModel));
        }

        // POST: Role/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,Name")] RoleViewModel roleViewModel)
        {
            if (ModelState.IsValid)
            {
                // db.Entry(roleViewModel).State = EntityState.Modified;
                var role = new ApplicatoinRole() { Id = roleViewModel.Id, Name = roleViewModel.Name };
                await RoleManager.UpdateAsync(role);

                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(roleViewModel);
        }

        // GET: Role/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var role = await RoleManager.FindByIdAsync(id);
            if (role == null)
            {
                return HttpNotFound();
            }
            await RoleManager.DeleteAsync(role);

            return RedirectToAction("Index");
        }

        public ActionResult AddRole(string id)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            foreach (var data in RoleManager.Roles)
            {
                list.Add(new SelectListItem()
                {
                    Text = data.Name,
                    Value = data.Name
                });
            }
            ViewBag.roleName = list;

            return View();
        }

        [HttpPost]
        public async Task<ActionResult> AddRole(string id, string roleName)
        {
            //return Content(roleName);

            await UserManager.AddToRoleAsync(id, roleName);

            return RedirectToAction("Index", "Admin");
        }

        //// POST: Role/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(string id)
        //{
        //    RoleViewModel roleViewModel = db.RoleViewModels.Find(id);
        //    db.RoleViewModels.Remove(roleViewModel);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}