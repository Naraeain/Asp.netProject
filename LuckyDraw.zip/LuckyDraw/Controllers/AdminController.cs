﻿using LuckyDraw.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LuckyDraw.Controllers
{

    [Authorize(Roles ="Admin")]
    public class AdminController : Controller
    {
        ApplicationDbContext db = new ApplicationDbContext();
        // GET: Admin
        public ActionResult Index()
        {
            List<SelectListItem> list = new List<SelectListItem>();

            if (GetOtherPrizeNumber() == null)
            {
                ViewBag.isEmpty = "There is no winning number";
            }
            else
            {
                foreach (var item in GetOtherPrizeNumber())
                {
                    list.Add(new SelectListItem() { Text = item.ToString(), Value = item.ToString() });
                }
                ViewBag.number = list;

            }
            return View();
        }



        [HttpPost]

        public ActionResult Index(Prize user, string number, string isRandom)
        {
            if (String.IsNullOrEmpty(user.PrizeType))
            {
                ModelState.AddModelError("PrizeType", "Please select prizetype for draw");
                return View();

            }
            //For User Grand Prize  bro
            if (user.PrizeType.Equals("1"))
            {
                var data = db.Prizes.Where(x => x.PrizeType == user.PrizeType).FirstOrDefault();
                if (data == null)
                {
                    List<int> numbers = GetGrandPrizeNumber().ToList();
                    var random = new Random();
                    var index = random.Next(numbers.Count);
                    var firzePrizeWinner = numbers[index];
                    var winnerDetail = db.winningNumbers.Where(x => x.WinningNumber == firzePrizeWinner).FirstOrDefault();
                    user.PrizeType = "1";
                    user.UserId = winnerDetail.UserId;
                    user.WinningNumber = firzePrizeWinner;
                    db.Prizes.Add(user);
                    int a = db.SaveChanges();
                    if (a > 0)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return View();
                    }
                }
                else
                {
                    ModelState.AddModelError("PrizeType", "The prize is already draw");
                    return View();
                }


            }
            else
            {
                if (isRandom.Equals("1"))
                {
                    var data = db.Prizes.Where(x => x.PrizeType == user.PrizeType).FirstOrDefault();
                    if (data == null)
                    {
                        try
                        {
                            var numbers = GetOtherPrizeNumber().ToList();
                            if (numbers.Count <= 0)
                            {

                                ModelState.AddModelError("PrizeType", "There is no user for prize ");
                                return View();
                            }
                            else
                            {
                                var random = new Random();
                                var index = random.Next(numbers.Count);
                                var otherWinner = numbers[index];
                                var winnerDetail = db.winningNumbers.Where(x => x.WinningNumber == otherWinner).FirstOrDefault();

                                user.UserId = winnerDetail.UserId;
                                user.WinningNumber = otherWinner;
                                db.Prizes.Add(user);
                                int a = db.SaveChanges();
                                if (a > 0)
                                {

                                    return RedirectToAction("Index");
                                }
                                else
                                {
                                    return View();
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            ModelState.AddModelError("PrizeType", "First select the first prize then other");
                            return View();
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("PrizeType", "The prize is already draw");
                        return View();
                    }

                }
                else
                {
                    if (string.IsNullOrEmpty(number))
                    {
                        ModelState.AddModelError("number", "Enter a value number");
                        return View();
                    }
                    else
                    {
                        try
                        {
                            var num = Convert.ToInt32(number);
                            var data = db.Prizes.Where(x => x.PrizeType == user.PrizeType).FirstOrDefault();
                            if (data == null)
                            {

                                var winnerDetail = db.winningNumbers.Where(x => x.WinningNumber == num).FirstOrDefault();
                                if (winnerDetail == null)
                                {
                                    ModelState.AddModelError("number", "The wining Number is Not Match");
                                    return View();
                                }
                                user.UserId = winnerDetail.UserId;
                                user.WinningNumber = num;
                                db.Prizes.Add(user);
                                int a = db.SaveChanges();
                                if (a > 0)
                                {

                                    return RedirectToAction("Index");
                                }
                                else
                                {
                                    return View();
                                }
                            }
                            else
                            {
                                ModelState.AddModelError("PrizeType", "The prize is already draw");
                                return View();
                            }

                        }
                        catch (Exception e)
                        {
                            ModelState.AddModelError("number", "Please enter four digit number from 1000 to 9999");
                            return View();

                        }
                    }
                }
            }

            //return View();
        }

        //Get GrandPrize Number from Winning Number Tabel
        private IOrderedEnumerable<int> GetGrandPrizeNumber()
        {
            Random r = new Random();
            List<int> numbers = new List<int>();
            var list = db.winningNumbers.AsQueryable();
            var GroupByUserId = list.GroupBy(x => x.UserId).OrderByDescending(x => x.Count()).Take(2);
            foreach (var groupData in GroupByUserId)
            {

                foreach (var OnlyEmp in groupData)
                {
                    numbers.Add(OnlyEmp.WinningNumber);
                }
            }

            var lists = numbers.OrderBy(x => r.Next(numbers.Count));

            return lists;
        }


        //Get Prize Number Which are not the Grand Prize Number After Grand Prize Is Draw
        private IOrderedEnumerable<int> GetOtherPrizeNumber()
        {
            Random r = new Random();
            List<int> numbers = new List<int>();
            //  string[] userArray = new string[2];
            var getWinnerList = db.Prizes.ToList();
            if (getWinnerList.Count <= 0)
            {
                return null;
            }
            else
            {
                var allNumber = db.winningNumbers.ToList();
                foreach (var item in allNumber)
                {
                    numbers.Add(item.WinningNumber);
                }

                foreach (var item in GetWinnnerNumber())
                {
                    numbers.Remove(item);
                }
                var list = numbers.OrderBy(x => r.Next(numbers.Count));

                return list;

            }


        }

        //Get All  List of User
        public ActionResult GetUser()
        {
            List<UserList> userLists = new List<UserList>();

            var users = db.Users.ToList();
            foreach (var user in users)
            {
                userLists.Add(new UserList() { Email = user.Email, Id = user.Id, Name = user.UserName });
            }
            return View(userLists);
        }


        //Get All of Winner's Winning Number
        private IOrderedEnumerable<int> GetWinnnerNumber()
        {
            Random r = new Random();
            List<int> AllWinnerNumber = new List<int>();
            var data = db.Prizes.ToList();
            if (data.Count > 0)
            {
                foreach (var user in data)
                {
                    var userNumber = db.winningNumbers.Where(x => x.UserId == user.UserId).ToList();

                    foreach (var item in userNumber)
                    {
                        AllWinnerNumber.Add(item.WinningNumber);
                    }
                }
            }
            var list = AllWinnerNumber.OrderBy(x => r.Next(AllWinnerNumber.Count));

            return list;
        }


        public ActionResult Delete()
        {
            var data = db.Prizes;

            if (data != null)
            {
                foreach (var item in data)
                {
                    db.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                }

                if (db.SaveChanges() > 0)
                {
                    return RedirectToAction("Result", "Home");

                }


            }
            return RedirectToAction("Index");


        }

    }
}