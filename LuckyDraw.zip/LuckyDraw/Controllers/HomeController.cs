﻿using LuckyDraw.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LuckyDraw.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        ApplicationDbContext db = new ApplicationDbContext();
        [AllowAnonymous]
        public ActionResult Index()
        {
            if (Session["UserId"] != null)
            {
                List<SelectListItem> list = new List<SelectListItem>();
                string userId = Session["UserId"].ToString();
                List<WinningNumbers> number = db.winningNumbers.Where(model => model.UserId == userId).ToList();
                //var data = db.winningNumbers.Where(x => x.UserId == Session["UserId"]).ToList();
                foreach (var item in number)
                {
                    list.Add(new SelectListItem() { Text = item.WinningNumber.ToString(), Value = item.WinningNumber.ToString() });
                }

                ViewBag.number = list;
            }


            return View();
        }

        [HttpPost]
        public ActionResult Index(WinningNumbers winning)
        {
            if (string.IsNullOrEmpty(winning.Number.ToString()) && winning.isRandom.Equals("0"))
            {
                ModelState.AddModelError("isRandom", "Please select yes or enter a number below");
                return View();

            }
            if (db.winningNumbers.Where(x => x.UserId == winning.UserId).ToList().Count > 10)
            {
                ModelState.AddModelError("isRandom", "You already enter 10 number!");
            }
            if (ModelState.IsValid)
            {
                if (string.IsNullOrEmpty(winning.isRandom))
                {
                    ModelState.AddModelError("isRandom", "Please select something");
                    return View();
                }

                if (winning.isRandom.Equals("1"))
                {
                    var data = Ramdom(1000, 9999);
                    var number = db.winningNumbers.Where(x => x.WinningNumber == data).FirstOrDefault();
                    if (number == null)
                    {
                        winning.WinningNumber = data;
                        db.winningNumbers.Add(winning);
                        int a = db.SaveChanges();
                        if (a > 0)
                        {
                           
                            return RedirectToAction("Index");
                        }
                        else
                        {
                            ViewBag.data = "Fail try again bro";
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("isRandom", "This number is already taken try again!");
                    }


                    return View();
                }
                else
                {
                    try
                    {
                        var data = Convert.ToInt32(winning.Number);
                        var number = db.winningNumbers.Where(x => x.WinningNumber == data).FirstOrDefault();
                        if (number == null)
                        {
                            winning.WinningNumber = data;
                            db.winningNumbers.Add(winning);
                            int a = db.SaveChanges();
                            if (a > 0)
                            {
                                // ViewBag.data = "<script>alert('Inserted')</script>";
                                return RedirectToAction("Index");
                            }
                            else
                            {
                                ViewBag.data = "Fail try again bro";
                            }
                        }
                        else
                        {
                            ModelState.AddModelError("isRandom", "This number is already taken try again");
                        }

                    }
                    catch (Exception e)
                    {

                    }
                    //  var data=db.winningNumbers.Where()
                    return View();
                }

               // return View();


            }
            return View();
           // return View();
        }

        private int Ramdom(int v1, int v2)
        {
            Random random = new Random();

            return random.Next(v1, v2);
            // throw new NotImplementedException();
        }
        [AllowAnonymous]
        public ActionResult Result()
        {
            List<WinnerDetail> winnerDetails = new List<WinnerDetail>();
            var data = db.Prizes.ToList();
            foreach (var item in data)
            {
                WinnerDetail winner = new WinnerDetail();
                var user = db.Users.Where(x => x.Id == item.UserId).FirstOrDefault();
                winner.WinnerName = user.UserName;
                winner.WinnerEmail = user.Email;
                winner.WinningNumber = item.WinningNumber.ToString();
                winner.WinningPirze = db.PrizeLists.Where(x => x.Id.ToString() == item.PrizeType).FirstOrDefault().prizeName;

                winnerDetails.Add(winner);
            }
            return View(winnerDetails);
        }
    }
}