﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(LuckyDraw.Startup))]
namespace LuckyDraw
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
