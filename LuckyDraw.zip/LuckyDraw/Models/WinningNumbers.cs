﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace LuckyDraw.Models
{
    public class WinningNumbers
    {
        public int Id { get; set; }


        [Required(ErrorMessage = "First Login Bro")]
        public string UserId { get; set; }

        [Required]
        [Index(IsUnique = true)]
        public int WinningNumber { get; set; }

        [DisplayName("Generate Randomly")]
        public string isRandom { get; set; }

        [DisplayName("Enter Winning Number")]
        [RegularExpression(@"\d{4}", ErrorMessage = "Enter 4 Digit Number")]
        // [StringLength(4,MinimumLength =4,ErrorMessage ="Digit must be 4")]
        public int? Number { get; set; }

    }
}