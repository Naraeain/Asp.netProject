﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LuckyDraw.Models
{
    public class PrizeList
    {
        public int Id { get; set; }

        public string prizeName { get; set; }
    }
}