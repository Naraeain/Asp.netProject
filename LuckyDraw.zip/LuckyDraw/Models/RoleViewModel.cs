﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LuckyDraw.Models
{
    public class RoleViewModel
    {
        public RoleViewModel() { }
        public RoleViewModel(ApplicatoinRole rolename)
        {
            Id = rolename.Id;
            Name = rolename.Name;

        }

        public string Id { get; set; }
        public string Name { get; set; }
    }
}