﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LuckyDraw.Models
{
    public class UserList
    {
        public UserList() { }

        public UserList(string id, string email, string name)
        {
            Id = id;
            Email = email;
            Name = name;
        }
        public string Id { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }


    }
}