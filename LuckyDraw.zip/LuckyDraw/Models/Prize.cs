﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LuckyDraw.Models
{
    public class Prize
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Select Prize For User")]
        [Display(Name = "Select Prize Type *")]
        public string PrizeType { get; set; }

        [Required]
        // [RegularExpression(@"\d{4}")]
        public int WinningNumber { get; set; }

        [Required]
        public string UserId { get; set; }
    }
}