﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LuckyDraw.Models
{
    public class WinnerDetail
    {
        public string WinnerName { get; set; }

        public string WinningNumber { get; set; }

        public string WinningPirze { get; set; }

        public string WinnerEmail { get; set; }

    }
}